-- README.txt --
This application calculates currency price in SEK read from rates.csv. 

functions:

get the year average of EUR/USD/GBP/CHF/CNY in SEK.
get the month average of EUR/USD/GBP/CHF/CNY in SEK.
get the highest/Lowest price of EUR/USD/GBP/CHF/CNY in SEK.

get the average of EUR/USD/GBP/CHF/CNY in a specified start and end date in SEK.
get the highest/lowest price of EUR/USD/GBP/CHF/CNY in a specified start and end date in SEK.

---------------------------------------------------------------------------------------------------
Made by: Andreas Johansson.