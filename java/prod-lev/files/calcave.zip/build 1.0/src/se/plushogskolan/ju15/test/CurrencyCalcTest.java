package se.plushogskolan.ju15.test;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import org.junit.Test;

import se.plushogskolan.ju15.beans.CurrencyCalcBean;
import se.plushogskolan.ju15.model.CurrencyCalcModel;

public class CurrencyCalcTest {
	
		CurrencyCalcModel currencyModel = new CurrencyCalcModel();
		CurrencyCalcBean currencyBean = new CurrencyCalcBean();
		

		// test to check yearly salary
		@Test
		public void testGetYearAverage() {
			currencyModel.loadData();
			System.out.println("Testing method 'testGetYearAverage()'");
			BigDecimal average = currencyModel.getYearAverage("EUR", 2015);
			System.out.println(average);
			assertEquals(new BigDecimal(9.3649203).setScale(7, RoundingMode.HALF_UP), average);
		}
		
		@Test
		public void testGetMonthAverage() {
			currencyModel.loadData();
			System.out.println("Testing method 'testGetMonthAverage()'");
			BigDecimal average = currencyModel.getMonthAverage("USD", 2014, 10);
			System.out.println(average);
			assertEquals(new BigDecimal(7.2361544).setScale(7, RoundingMode.HALF_UP), average);
		}
		
		@Test
		public void testGetAverage() {
			currencyModel.loadData();
			System.out.println("Testing method 'testGetAverage()'");
			BigDecimal average = currencyModel.getAverage("EUR", LocalDate.of(2014, 10, 1), LocalDate.of(2015, 10, 1));
			System.out.println(average);
			assertEquals(new BigDecimal(9.3477477).setScale(7, RoundingMode.HALF_UP), average);
		}
		
		@Test
		public void testGetYearHigh() {
			currencyModel.loadData();
			System.out.println("Testing method 'testGetYearHigh()'");
			BigDecimal average = currencyModel.getYearHigh("EUR", 2015);
			System.out.println(average);
			assertEquals( new BigDecimal(9.6339113680).setScale(10, RoundingMode.HALF_UP) , average);
		}
		
		@Test
		public void testGetYearLow() {
			currencyModel.loadData();
			System.out.println("Testing method 'testGetYearLow()'");
			BigDecimal average = currencyModel.getYearLow("EUR", 2015);
			System.out.println(average);
			assertEquals( new BigDecimal(9.1074681239).setScale(10, RoundingMode.HALF_UP) , average);
		}
		
		@Test
		public void testGetMonthHigh() {
			currencyModel.loadData();
			System.out.println("Testing method 'testGetMonthHigh()'");
			BigDecimal average = currencyModel.getMonthHigh("EUR", 2015, 10);
			System.out.println(average);
			assertEquals( new BigDecimal(9.4339622642).setScale(10, RoundingMode.HALF_UP) , average);
		}
		
		@Test
		public void testGetMonthLow() {
			currencyModel.loadData();
			System.out.println("Testing method 'testGetMonthLow()'");
			BigDecimal average = currencyModel.getMonthLow("EUR", 2015, 10);
			System.out.println(average);
			assertEquals( new BigDecimal(9.2678405931).setScale(10, RoundingMode.HALF_UP) , average);
		}
		
		@Test
		public void testGetHighMark() {
			currencyModel.loadData();
			System.out.println("Testing method 'testGetHighMark()'");
			BigDecimal average = currencyModel.getHighMark("EUR", LocalDate.of(2014, 10, 15), LocalDate.of(2015, 10, 15));
			System.out.println(average);
			assertEquals(  new BigDecimal(9.6339113680).setScale(10, RoundingMode.HALF_UP) , average);
		}
		
		@Test
		public void testGetLowMark() {
			currencyModel.loadData();
			System.out.println("Testing method 'testGetLowMark()'");
			BigDecimal average = currencyModel.getLowMark("EUR", LocalDate.of(2014, 10, 15), LocalDate.of(2015, 10, 15));
			System.out.println(average);
			assertEquals(  new BigDecimal(9.1074681239).setScale(10, RoundingMode.HALF_UP), average);
		}
		
		@Test
		public void testConvertMonth() {
			System.out.println("Testing method 'testConvertMonth()'");
			int num = currencyModel.convertMonth("Oct");
			System.out.println(num);
			assertEquals(10, num);
		}
}
