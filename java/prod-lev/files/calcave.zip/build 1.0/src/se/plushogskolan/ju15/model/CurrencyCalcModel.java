package se.plushogskolan.ju15.model;

import java.math.BigDecimal;

import java.math.RoundingMode;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import se.plushogskolan.ju15.beans.CurrencyCalcBean;
// Fixa:
// s�tt ihop funktioner som �r v�ldigt lika.
/**
 * CurrencyCalcModel - this class contains methods for calculating currency price in SEK.
 * @author Andreas
 *
 */
public class CurrencyCalcModel {
	CurrencyCalcBean currencyBean = new CurrencyCalcBean();
	
	private ObservableList<CurrencyCalcBean> currencyData = FXCollections.observableArrayList();
	/**
	 * returns the yearly average from a specified currency.
	 * @param currency currency a String variable.
	 * @param year year an Integer variable.
	 * @return returns a BigDecimal value.
	 */
	public BigDecimal getYearAverage(String currency, Integer year) {
		BigDecimal count = new BigDecimal(0);
		BigDecimal sum = new BigDecimal(0);
		for (int i=0; i<=currencyData.size()-1; i++) {
			if (currencyData.get(i).getYear().equals(year)) {
				if (currencyData.get(i).getCurrencyName().equals(currency)) {
					count = count.add(new BigDecimal(1));
					sum = sum.add((currencyData.get(i).getCurrency()));
				}
			}
		}
		return sum.divide(count, 7, RoundingMode.HALF_UP);
	}
	
	/**
	 * returns the monthly average from a specified currency and year.
	 * @param currency currency a String variable.
	 * @param year year an Integer variable.
	 * @param month month an Integer variable.
	 * @return returns a BigDecimal value.
	 */
	public BigDecimal getMonthAverage(String currency, Integer year, Integer month) {
		BigDecimal count = new BigDecimal(0);
		BigDecimal sum = new BigDecimal(0);
		for (int i=0; i<=currencyData.size()-1; i++) {
			if (currencyData.get(i).getYear().equals(year)) {
				if (currencyData.get(i).getMonth().equals(month)) {
					if (currencyData.get(i).getCurrencyName().equals(currency)) {
						count = count.add(new BigDecimal(1));
						sum = sum.add((currencyData.get(i).getCurrency()));
					}
				}
			
			}
		}
		return sum.divide(count, 7, RoundingMode.HALF_UP);
	}
	
	/**
	 * returns the average from a specified date and currency.
	 * @param currency currency a String variable.
	 * @param fromDate fromDate a LocalDate object.
	 * @param toDate toDate a LocalDate object.
	 * @return returns a BigDecimal value.
	 */
	public BigDecimal getAverage(String currency, LocalDate fromDate, LocalDate toDate) {
		long days = ChronoUnit.DAYS.between(fromDate, toDate)+1;
		int index = 0;
		BigDecimal count = new BigDecimal(0);
		BigDecimal sum = new BigDecimal(0);
		
		for (int i=0; i<=currencyData.size()-1; i++) {
			if (currencyData.get(i).getYear().equals(fromDate.getYear())) {
				if (currencyData.get(i).getMonth().equals(fromDate.getMonthValue())) {
					if (currencyData.get(i).getDay().equals(fromDate.getDayOfMonth())) {
						if (currencyData.get(i).getCurrencyName().equals(currency)) {
							index = i; //Find Index for start date
						}
					}
				}
			
			}
		}
		
		System.out.println("Index: " + index);
		System.out.println("Days: " + days);
		
		for (int i=index; i>=index+1-(int) days*5; i--) {
			if (currencyData.get(i).getCurrencyName().equals(currency)) { // Kom ih�g equals...
				count = count.add(new BigDecimal(1));
				sum = sum.add( currencyData.get(i).getCurrency() );
			}
		}
		System.out.println("Count: " + count);
		return sum.divide(count, 7, RoundingMode.HALF_UP);
	}

	/**
	 * returns the highest price of a currency in the specified year.
	 * @param currency currency a String variable.
	 * @param year year an Integer variable.
	 * @return returns a BigDecimal value.
	 */
	public BigDecimal getYearHigh(String currency, Integer year) {
		ArrayList<BigDecimal> tempArray = new ArrayList<BigDecimal>();
		
		for (int i=0; i<=currencyData.size()-1; i++) {
			if (currencyData.get(i).getYear().equals(year)) {
				if (currencyData.get(i).getCurrencyName().equals(currency)) {
					tempArray.add(currencyData.get(i).getCurrency());
				}	
			}
		}
		Collections.sort(tempArray);
		return tempArray.get(tempArray.size()-1);
	}

	/**
	 * returns the lowest price of a currency in the specified year.
	 * @param currency currency a String variable.
	 * @param year year an Integer variable.
	 * @return returns a BigDecimal value.
	 */
	public BigDecimal getYearLow(String currency, Integer year) {
		ArrayList<BigDecimal> tempArray = new ArrayList<BigDecimal>();
		
		for (int i=0; i<=currencyData.size()-1; i++) {
			if (currencyData.get(i).getYear().equals(year)) {
				if (currencyData.get(i).getCurrencyName().equals(currency)) {
					tempArray.add(currencyData.get(i).getCurrency());
				}	
			}
		}
		Collections.sort(tempArray);
		return tempArray.get(0);
	}

	/**
	 * returns the highest price of a currency in the specified month and year.
	 * @param currency currency a String variable.
	 * @param year year an Integer variable.
	 * @param month month an Integer variable.
	 * @return returns a BigDecimal value.
	 */
	public BigDecimal getMonthHigh(String currency, Integer year, Integer month) {
		ArrayList<BigDecimal> tempArray = new ArrayList<BigDecimal>();
		
		for (int i=0; i<=currencyData.size()-1; i++) {
			if (currencyData.get(i).getYear().equals(year)) {
				if (currencyData.get(i).getMonth().equals(month)) {
					if (currencyData.get(i).getCurrencyName().equals(currency)) {
						tempArray.add(currencyData.get(i).getCurrency());
					}	
				}
			}
		}
		Collections.sort(tempArray);
		return tempArray.get(tempArray.size()-1);
	}

	/**
	 * returns the lowest price of a currency in the specified month and year.
	 * @param currency currency a String variable.
	 * @param year year an Integer variable.
	 * @param month month an Integer variable.
	 * @return returns a BigDecimal value.
	 */
	public BigDecimal getMonthLow(String currency, Integer year, Integer month) {
		ArrayList<BigDecimal> tempArray = new ArrayList<BigDecimal>();
		
		for (int i=0; i<=currencyData.size()-1; i++) {
			if (currencyData.get(i).getYear().equals(year)) {
				if (currencyData.get(i).getMonth().equals(month)) {
					if (currencyData.get(i).getCurrencyName().equals(currency)) {
						tempArray.add(currencyData.get(i).getCurrency());
					}	
				}
			}
		}
		
		Collections.sort(tempArray);
		return tempArray.get(0);
	}

	/**
	 * returns the highest price of a currency in the specified period.
	 * @param currency currency a String variable.
	 * @param fromDate fromDate a LocalDate value.
	 * @param toDate toDate a LocalDate value.
	 * @return returns a BigDecimal value.
	 */
	public BigDecimal getHighMark(String currency, LocalDate fromDate, LocalDate toDate) {
		ArrayList<BigDecimal> tempArray = new ArrayList<BigDecimal>();
		
		long days = ChronoUnit.DAYS.between(fromDate, toDate)+1;
		int index = 0;
		
		for (int i=0; i<=currencyData.size()-1; i++) {
			if (currencyData.get(i).getYear().equals(fromDate.getYear())) {
				if (currencyData.get(i).getMonth().equals(fromDate.getMonthValue())) {
					if (currencyData.get(i).getDay().equals(fromDate.getDayOfMonth())) {
						if (currencyData.get(i).getCurrencyName().equals(currency)) {
							index = i; // Start Index.
						}
					}
				}
			
			}
		}
		
		System.out.println("Index: " + index);
		System.out.println("Days: " + days);
		
		for (int i=index; i>=index+1-(int) days*5; i--) {
			if (currencyData.get(i).getCurrencyName().equals(currency)) { // Kom ih�g equals...
				tempArray.add(currencyData.get(i).getCurrency());
			}
		}
		Collections.sort(tempArray);
		return tempArray.get(tempArray.size()-1);
	}

	/**
	 * returns the lowest price of a currency in the specified period.
	 * @param currency currency a String variable
	 * @param fromDate fromDate a LocalDate value.
	 * @param toDate toDate a LocalDate value.
	 * @return returns a BigDecimal value.
	 */
	public BigDecimal getLowMark(String currency, LocalDate fromDate, LocalDate toDate) {
		ArrayList<BigDecimal> tempArray = new ArrayList<BigDecimal>();
		
		long days = ChronoUnit.DAYS.between(fromDate, toDate)+1;
		int index = 0;
		
		for (int i=0; i<=currencyData.size()-1; i++) {
			if (currencyData.get(i).getYear().equals(fromDate.getYear())) {
				if (currencyData.get(i).getMonth().equals(fromDate.getMonthValue())) {
					if (currencyData.get(i).getDay().equals(fromDate.getDayOfMonth())) {
						if (currencyData.get(i).getCurrencyName().equals(currency)) {
							index = i; // Start Index.
						}
					}
				}
			
			}
		}
		
		System.out.println("Index: " + index);
		System.out.println("Days: " + days);
		
		for (int i=index; i>=index+1-(int) days*5; i--) {
			if (currencyData.get(i).getCurrencyName().equals(currency)) { // Kom ih�g equals...
				tempArray.add(currencyData.get(i).getCurrency());
			}
		}
		Collections.sort(tempArray);
		return tempArray.get(0);
	}
/*	
	// EXTRA //
	
	public String getMaxDeltaCurrency(LocalDate fromDate, LocalDate toDate) {
		
	}
	
	public String getMaxVolatilityCurrency(LocalDate fromDate, LocalDate toDate) {
		
	}
	
	public int getMaxVolatiliyWeek(String currency, int year) {
		
	}
	
	public BigDecimal getAvreage(String currency, LocalDate fromDate, LocalDate toDate, DayOfWeek weekDay) {
		
	}
*/
	
	/**
	 * loadData - reads data from rates.csv and map it to a bean in an ArrayList.
	 */
	public void loadData() {
		try {
			//System.out.println(Paths.get("mydata.txt").toAbsolutePath());
			List<String> lines = Files.readAllLines(Paths.get("rates.csv"), Charset.forName("UTF-8"));
			
			String[] firstLine = lines.get(0).split(";");	
			
			for (int i=1; i<=lines.size()-1; i++) {
				String line = lines.get(i); //0 �r f�rsta raden.
				String[] dataRaw = line.split(";");
				String[] dataDate = dataRaw[0].split(" ");
				
				if(!line.isEmpty()) {
					//dataDate[0] // M�nad String
					//dataDate[1] // Dag String
					//dataDate[2] // Year String
					for(int j=1;j<=firstLine.length-1;j++) {
						CurrencyCalcBean c = new CurrencyCalcBean(
							new BigDecimal(1).divide(new BigDecimal(dataRaw[j]), 10, RoundingMode.HALF_UP), 
							firstLine[j], 
							Integer.valueOf(dataDate[1].substring(0,dataDate[1].length()-1)), 
							convertMonth(dataDate[0]), Integer.valueOf(dataDate[2]));
						currencyData.add(c);
					}
					//System.out.println("Data in dataDate: " + dataDate[0] + " " + dataDate[1] + " " + dataDate[2]);
					//System.out.println("Data in dataRaw: " + dataRaw[1]  + " " + dataRaw[2]  + " " + dataRaw[3]  + " " + dataRaw[4]  + " " + dataRaw[5]);
				}
			}
			//System.out.println("Loaded " + lines.size() + " rows of data.");
		} catch (Exception e) {
			System.out.println("There was a problem loading the file:" + e.getMessage());
			e.printStackTrace();
		}
		
	}
	
	/**
	 * converts a 3 letter long month String to a number.
	 * @param month month a String variable.
	 * @return returns a Integer value.
	 */
	public Integer convertMonth(String month) {
		switch (month) {
			case "Jan": return 1;
			case "Feb": return 2;
			case "Mar": return 3;
			case "Apr": return 4;
			case "May": return 5;
			case "Jun": return 6;
			case "Jul": return 7;
			case "Aug": return 8;
			case "Sep": return 9;
			case "Oct": return 10;
			case "Nov": return 11;
			case "Dec": return 12;
		}
		return 0;
	}
	
	/**
	 * checks if a LocalDate exist in the rates.csv file.
	 * @param currency currency a String variable.
	 * @param date date a LocalDate object.
	 * @return return a boolean value.
	 */
	public boolean checkDate(String currency, LocalDate date) {
		// Checks if the specified currency dates exist inside the arraylist
		for (int i=0; i<=currencyData.size()-1; i++) {
			if (currencyData.get(i).getYear().equals(date.getYear())) {
				if (currencyData.get(i).getMonth().equals(date.getMonthValue())) {
					if (currencyData.get(i).getDay().equals(date.getDayOfMonth())) {
						return true; 
					}
				}
			
			}
		}
		return false;
	}

}
