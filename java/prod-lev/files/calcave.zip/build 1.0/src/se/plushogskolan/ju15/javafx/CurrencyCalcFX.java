package se.plushogskolan.ju15.javafx;

import java.time.LocalDate;
import javafx.application.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import se.plushogskolan.ju15.model.CurrencyCalcModel;

// Fixa:
// Anv�nds addEventListener ist�llet f�r anonyma funktioner
// d� mycket kod repeteras.
public class CurrencyCalcFX extends Application {
	CurrencyCalcModel calcModel = new CurrencyCalcModel();
	
	// Create ObsList for year,month,days,currency.
	ObservableList<String> monthOptions2013 =
			FXCollections.observableArrayList(
					"November",
					"December"
			);
	
	ObservableList<String> monthOptions2014 =
			FXCollections.observableArrayList(
					"January",
					"February",
					"March",
					"April",
					"May",
					"June",
					"July",
					"August",
					"September",
					"October",
					"November",
					"December"
			);
	
	ObservableList<String> monthOptions2015 =
			FXCollections.observableArrayList(
					"January",
					"February",
					"March",
					"April",
					"May",
					"June",
					"July",
					"August",
					"September",
					"October",
					"November"
			);
	
	
	
	ObservableList<String> yearOptions =
			FXCollections.observableArrayList(
					"2015",
					"2014",
					"2013"
			);

	ObservableList<String> curNameOptions =
			FXCollections.observableArrayList(
					"EUR",
					"USD",
					"GBP",
					"CHF",
					"CNY"
			);
	
	public static void main(String[] args) {
		launch(args);
	}
	
	public void init() {
		calcModel.loadData();
	}
	
	@SuppressWarnings("unchecked") // mycket generic som inte �r satt.
	public void start(Stage myStage) {
		// Get Year Average //
		
		Label getYearAverageHead = new Label("Calculate Year Average");
		Label getYearAverageText = new Label();
		
		ComboBox comBoxGetYearAverageY = new ComboBox(yearOptions);
		ComboBox comBoxGetYearAverageCur = new ComboBox(curNameOptions);
		
		comBoxGetYearAverageCur.setValue("EUR");
		comBoxGetYearAverageY.setValue("2015");
		
		comBoxGetYearAverageCur.setOnAction((event) -> {
			getYearAverageText.setText(
					calcModel.getYearAverage(comBoxGetYearAverageCur.getValue().toString(), 
							Integer.parseInt(comBoxGetYearAverageY.getValue().toString())).toString()
					+ " SEK");
		});
		
		comBoxGetYearAverageY.setOnAction((event) -> {
			getYearAverageText.setText(
					calcModel.getYearAverage(comBoxGetYearAverageCur.getValue().toString(), 
							Integer.parseInt(comBoxGetYearAverageY.getValue().toString())).toString()
					+ " SEK"
			);	
		});
		
		getYearAverageText.setText( 
					calcModel.getYearAverage(comBoxGetYearAverageCur.getValue().toString(), 
					Integer.parseInt(comBoxGetYearAverageY.getValue().toString())).toString()
					+ " SEK"
		);
		
		// Get Month Average //
		
		Label getMonthAverageHead = new Label("Calculate Month Average");
		Label getMonthAverageText = new Label();
		
		ComboBox comBoxGetMonthAverageY = new ComboBox(yearOptions);
		ComboBox comBoxGetMonthAverageCur = new ComboBox(curNameOptions);
		ComboBox comBoxGetMonthAverageM = new ComboBox(monthOptions2015);
		
		comBoxGetMonthAverageCur.setValue("EUR");
		comBoxGetMonthAverageY.setValue("2015");
		comBoxGetMonthAverageM.setValue("November");
		
		comBoxGetMonthAverageCur.setOnAction((event) -> {
			getMonthAverageText.setText(
					calcModel.getMonthAverage(comBoxGetMonthAverageCur.getValue().toString(), 
							Integer.parseInt(comBoxGetMonthAverageY.getValue().toString()),
							calcModel.convertMonth(comBoxGetMonthAverageM.getValue().toString().substring(0,3))).toString()
					+ " SEK"
			);
		});
		
		comBoxGetMonthAverageY.setOnAction((event) -> {
			checkCombo(comBoxGetMonthAverageY, comBoxGetMonthAverageM);
			getMonthAverageText.setText(
					calcModel.getMonthAverage(comBoxGetMonthAverageCur.getValue().toString(), 
							Integer.parseInt(comBoxGetMonthAverageY.getValue().toString()),
							calcModel.convertMonth(comBoxGetMonthAverageM.getValue().toString().substring(0,3))).toString()
					+ " SEK"
			);	
		});
		
		comBoxGetMonthAverageM.setOnAction((event) -> {
			if (comBoxGetMonthAverageM.getValue() != null) {
				getMonthAverageText.setText(
						calcModel.getMonthAverage(comBoxGetMonthAverageCur.getValue().toString(), 
								Integer.parseInt(comBoxGetMonthAverageY.getValue().toString()),
								calcModel.convertMonth(comBoxGetMonthAverageM.getValue().toString().substring(0,3))).toString()
						+ " SEK"
				);	
			}
		});
		
		getMonthAverageText.setText(
				calcModel.getMonthAverage(comBoxGetMonthAverageCur.getValue().toString(), 
						Integer.parseInt(comBoxGetMonthAverageY.getValue().toString()),
						calcModel.convertMonth(comBoxGetMonthAverageM.getValue().toString().substring(0,3))).toString()
				+ " SEK"
		);
		
		// Get Average Period //
		Label getAveragePeriodHead = new Label("Calculate Average Custom Date");
		Label getAveragePeriodText = new Label("0");
		
		ComboBox comBoxGetAveragePeriodCur = new ComboBox(curNameOptions);
		TextField tfGetAveragePeriodStart = new TextField();
		TextField tfGetAveragePeriodEnd = new TextField();
		Button buttonGetAveragePeriodCommit = new Button("Commit");
		
		comBoxGetAveragePeriodCur.setValue("EUR");
		tfGetAveragePeriodStart.setPromptText("YYYY-MM-DD");
		tfGetAveragePeriodEnd.setPromptText("YYYY-MM-DD");
		
		buttonGetAveragePeriodCommit.setOnAction((event) -> {
			boolean startOk = false;
			boolean endOk = false;
			if (comBoxGetAveragePeriodCur.getValue() != null) {
				try {
					String[] dateStart = tfGetAveragePeriodStart.getText().split("-"); 
					if (dateStart[0] != null) {
						if (dateStart[1] != null) {
							if (dateStart[2] != null) {
								if ( calcModel.checkDate(
										comBoxGetAveragePeriodCur.getValue().toString(), 
										LocalDate.of(
												Integer.parseInt(dateStart[0]), 
												Integer.parseInt(dateStart[1]), 
												Integer.parseInt(dateStart[2])
										)
									) 
								) {
									startOk = true;
								}
								else {
									alert("selected start date does not exist in rates.csv");
								}
								
							}
							else{
								alert("Start date for day is not set correctly");
							}
							      
						}
						else{
							alert("Start date for month is not set correctly");
						}
					}
					else{
						alert("Start date for year is not set correctly");
					}
					
				}
				catch (Exception e) {
					alert("Start date was not correctly set");
					//e.printStackTrace();
				}
				
				try {
					String[] dateEnd = tfGetAveragePeriodEnd.getText().split("-"); 
					if (dateEnd[0] != null) {
						if (dateEnd[1] != null) {
							if (dateEnd[2] != null) {
								if ( calcModel.checkDate(
										comBoxGetAveragePeriodCur.getValue().toString(), 
										LocalDate.of(
												Integer.parseInt(dateEnd[0]), 
												Integer.parseInt(dateEnd[1]), 
												Integer.parseInt(dateEnd[2])
										)
									) 
								) {
									endOk = true;
								}
								else {
									alert("selected end date does not exist in rates.csv");
								}
								
							}
							else{
								alert("end date day is not set correctly");
							}
							      
						}
						else{
							alert("end date month is not set correctly");
						}
					}
					else{
						alert("end date year is not set correctly");
					}
					
				}
				catch (Exception e) {
					alert("End Date was not correctly set");
					//e.printStackTrace();
				}
			}
			else {
				System.out.println("Select a currency");
			}
			
			if (startOk && endOk ) {
				System.out.println("OK");
				String[] startDate = tfGetAveragePeriodStart.getText().split("-");
				String[] endDate = tfGetAveragePeriodEnd.getText().split("-");
				getAveragePeriodText.setText(
					calcModel.getAverage(
						comBoxGetAveragePeriodCur.getValue().toString(), 
						LocalDate.of(
								Integer.parseInt(startDate[0]), 
								Integer.parseInt(startDate[1]), 
								Integer.parseInt(startDate[2])
						),
						LocalDate.of(
								Integer.parseInt(endDate[0]),
								Integer.parseInt(endDate[1]),
								Integer.parseInt(endDate[2])
						)
					).toString()
					+ " SEK"
				);
			}
			
		});
		
		// Get Year High and Low.
		Label getYearHLHead = new Label("Calculate Year High and Low");
		Label getYearHLText = new Label();
		
		ComboBox comBoxYearHL = new ComboBox(FXCollections.observableArrayList("High","Low"));
		ComboBox comBoxYearHLCur = new ComboBox(curNameOptions);
		ComboBox comBoxYearY = new ComboBox(yearOptions);
		
		comBoxYearHL.setValue("High");
		comBoxYearHLCur.setValue("EUR");
		comBoxYearY.setValue("2015");
		
		comBoxYearHL.setOnAction((event) -> {
			if (comBoxYearHL.getValue().equals("High")) {
				getYearHLText.setText(
						calcModel.getYearHigh(
								comBoxYearHLCur.getValue().toString(), 
								Integer.parseInt(comBoxYearY.getValue().toString())
						).toString()
						+ " SEK"
				);
			}
			else {
				getYearHLText.setText(
						calcModel.getYearLow(
								comBoxYearHLCur.getValue().toString(), 
								Integer.parseInt(comBoxYearY.getValue().toString())
						).toString()
						+ " SEK"
				);
			}
		});
		
		comBoxYearHLCur.setOnAction((event) -> {
			if (comBoxYearHL.getValue().equals("High")) {
				getYearHLText.setText(
						calcModel.getYearHigh(
								comBoxYearHLCur.getValue().toString(), 
								Integer.parseInt(comBoxYearY.getValue().toString())
						).toString()
						+ " SEK"
				);
			}
			else {
				getYearHLText.setText(
						calcModel.getYearLow(
								comBoxYearHLCur.getValue().toString(), 
								Integer.parseInt(comBoxYearY.getValue().toString())
						).toString()
						+ " SEK"
				);
			}
		});
		
		comBoxYearY.setOnAction((event) -> {
			if (comBoxYearHL.getValue().equals("High")) {
				getYearHLText.setText(
						calcModel.getYearHigh(
								comBoxYearHLCur.getValue().toString(), 
								Integer.parseInt(comBoxYearY.getValue().toString())
						).toString()
						+ " SEK"
				);
			}
			else {
				getYearHLText.setText(
						calcModel.getYearLow(
								comBoxYearHLCur.getValue().toString(), 
								Integer.parseInt(comBoxYearY.getValue().toString())
						).toString()
						+ " SEK"
				);
			}
		});
		
		if (comBoxYearHL.getValue().equals("High")) {
			getYearHLText.setText(
					calcModel.getYearHigh(
							comBoxYearHLCur.getValue().toString(), 
							Integer.parseInt(comBoxYearY.getValue().toString())
					).toString()
					+ " SEK"
			);
		}
		else {
			getYearHLText.setText(
					calcModel.getYearLow(
							comBoxYearHLCur.getValue().toString(), 
							Integer.parseInt(comBoxYearY.getValue().toString())
					).toString()
					+ " SEK"
			);
		}
		
		// Get Month High and Low
		Label getMonthHLHead = new Label("Calculate Month High and Low");
		Label getMonthHLText = new Label();
		
		ComboBox comBoxMonthHL = new ComboBox(FXCollections.observableArrayList("High","Low"));
		ComboBox comBoxMonthHLCur = new ComboBox(curNameOptions);
		ComboBox comBoxMonthY = new ComboBox(yearOptions);
		ComboBox comBoxMonthM = new ComboBox(monthOptions2015);
		
		comBoxMonthHL.setValue("High");
		comBoxMonthHLCur.setValue("EUR");
		comBoxMonthY.setValue("2015");
		comBoxMonthM.setValue("November");
		
		comBoxMonthHL.setOnAction((event) -> {
			if (comBoxMonthHL.getValue().equals("High")) {
				getMonthHLText.setText(
						calcModel.getMonthHigh(
								comBoxMonthHLCur.getValue().toString(), 
								Integer.parseInt(comBoxMonthY.getValue().toString()), 
								calcModel.convertMonth(comBoxMonthM.getValue().toString().substring(0,3))
						).toString()
						+ " SEK"
				);
			}
			else {
				getMonthHLText.setText(
						calcModel.getMonthLow(
								comBoxMonthHLCur.getValue().toString(), 
								Integer.parseInt(comBoxMonthY.getValue().toString()), 
								calcModel.convertMonth(comBoxMonthM.getValue().toString().substring(0,3))
						).toString()
						+ " SEK"
				);
			}
		});
		
		comBoxMonthHLCur.setOnAction((event) -> {
			if (comBoxMonthHL.getValue().equals("High")) {
				getMonthHLText.setText(
						calcModel.getMonthHigh(
								comBoxMonthHLCur.getValue().toString(), 
								Integer.parseInt(comBoxMonthY.getValue().toString()), 
								calcModel.convertMonth(comBoxMonthM.getValue().toString().substring(0,3))
						).toString()
						+ " SEK"
				);
			}
			else {
				getMonthHLText.setText(
						calcModel.getMonthLow(
								comBoxMonthHLCur.getValue().toString(), 
								Integer.parseInt(comBoxMonthY.getValue().toString()), 
								calcModel.convertMonth(comBoxMonthM.getValue().toString().substring(0,3))
						).toString()
						+ " SEK"
				);
			}
		});
		
		comBoxMonthY.setOnAction((event) -> {
			checkCombo(comBoxMonthY, comBoxMonthM);
			if (comBoxMonthHL.getValue().equals("High")) {
				getMonthHLText.setText(
						calcModel.getMonthHigh(
								comBoxMonthHLCur.getValue().toString(), 
								Integer.parseInt(comBoxMonthY.getValue().toString()), 
								calcModel.convertMonth(comBoxMonthM.getValue().toString().substring(0,3))
						).toString()
						+ " SEK"
				);
			}
			else {
				getMonthHLText.setText(
						calcModel.getMonthLow(
								comBoxMonthHLCur.getValue().toString(), 
								Integer.parseInt(comBoxMonthY.getValue().toString()), 
								calcModel.convertMonth(comBoxMonthM.getValue().toString().substring(0,3))
						).toString()
						+ " SEK"
				);
			}
		});
		
		comBoxMonthM.setOnAction((event) -> {
			if (comBoxMonthM.getValue() != null) {
				if (comBoxMonthHL.getValue().equals("High")) {
					getMonthHLText.setText(
							calcModel.getMonthHigh(
									comBoxMonthHLCur.getValue().toString(), 
									Integer.parseInt(comBoxMonthY.getValue().toString()), 
									calcModel.convertMonth(comBoxMonthM.getValue().toString().substring(0,3))
							).toString()
							+ " SEK"
					);
				}
				else {
					getMonthHLText.setText(
							calcModel.getMonthLow(
									comBoxMonthHLCur.getValue().toString(), 
									Integer.parseInt(comBoxMonthY.getValue().toString()), 
									calcModel.convertMonth(comBoxMonthM.getValue().toString().substring(0,3))
							).toString()
							+ " SEK"
					);
				}
			}
		});
		
		if (comBoxMonthHL.getValue().equals("High")) {
			getMonthHLText.setText(
					calcModel.getMonthHigh(
							comBoxMonthHLCur.getValue().toString(), 
							Integer.parseInt(comBoxMonthY.getValue().toString()), 
							calcModel.convertMonth(comBoxMonthM.getValue().toString().substring(0,3))
					).toString()
					+ " SEK"
			);
		}
		else {
			getMonthHLText.setText(
					calcModel.getMonthLow(
							comBoxMonthHLCur.getValue().toString(), 
							Integer.parseInt(comBoxMonthY.getValue().toString()), 
							Integer.parseInt(comBoxMonthM.getValue().toString())
					).toString()
					+ " SEK"
			);
		}
		
		// Get High Low in period.
		// Get Average Period //
		Label getMarkHLHead = new Label("Calculate High and Low with custom dates");
		Label getMarkHLText = new Label("0");
		
		ComboBox comBoxGetMarkHLCur = new ComboBox(curNameOptions);
		ComboBox comBoxGetMarkHL = new ComboBox(FXCollections.observableArrayList("High","Low"));
		TextField tfGetMarkHLStart = new TextField();
		TextField tfGetMarkHLEnd = new TextField();
		Button buttonGetMarkHLCommit = new Button("Commit");
		
		comBoxGetMarkHLCur.setValue("EUR");
		tfGetMarkHLStart.setPromptText("YYYY-MM-DD");
		tfGetMarkHLEnd.setPromptText("YYYY-MM-DD");
		comBoxGetMarkHL.setValue("High");
		
		buttonGetMarkHLCommit.setOnAction((event) -> {
			boolean startOk = false;
			boolean endOk = false;
			if (comBoxGetMarkHLCur.getValue() != null) {
				try {
					String[] dateStart = tfGetMarkHLStart.getText().split("-"); 
					if (dateStart[0] != null) {
						if (dateStart[1] != null) {
							if (dateStart[2] != null) {
								if ( calcModel.checkDate(
										comBoxGetMarkHLCur.getValue().toString(), 
										LocalDate.of(
												Integer.parseInt(dateStart[0]), 
												Integer.parseInt(dateStart[1]), 
												Integer.parseInt(dateStart[2])
										)
									) 
								) {
									startOk = true;
								}
								else {
									alert("selected start date does not exist in rates.csv");
								}
								
							}
							else{
								alert("Start date for day is not set correctly");
							}
							      
						}
						else{
							alert("Start date for month is not set correctly");
						}
					}
					else{
						alert("Start date for year is not set correctly");
					}
					
				}
				catch (Exception e) {
					alert("Start date was not correctly set");
					//e.printStackTrace();
				}
				
				try {
					String[] dateEnd = tfGetMarkHLEnd.getText().split("-"); 
					if (dateEnd[0] != null) {
						if (dateEnd[1] != null) {
							if (dateEnd[2] != null) {
								if ( calcModel.checkDate(
										comBoxGetMarkHLCur.getValue().toString(), 
										LocalDate.of(
												Integer.parseInt(dateEnd[0]), 
												Integer.parseInt(dateEnd[1]), 
												Integer.parseInt(dateEnd[2])
										)
									) 
								) {
									endOk = true;
								}
								else {
									alert("selected end date does not exist in rates.csv");
								}
								
							}
							else{
								alert("end date day is not set correctly");
							}
							      
						}
						else{
							alert("end date month is not set correctly");
						}
					}
					else{
						alert("end date year is not set correctly");
					}
					
				}
				catch (Exception e) {
					alert("End Date was not correctly set");
					//e.printStackTrace();
				}
			}
			else {
				System.out.println("Select a currency");
			}
			
			if (startOk && endOk ) {
				if (comBoxGetMarkHL.getValue().equals("High")) {
					//System.out.println("OK");
					String[] startDate = tfGetMarkHLStart.getText().split("-");
					String[] endDate = tfGetMarkHLEnd.getText().split("-");
					getMarkHLText.setText(
						calcModel.getHighMark(
							comBoxGetMarkHLCur.getValue().toString(), 
							LocalDate.of(
									Integer.parseInt(startDate[0]), 
									Integer.parseInt(startDate[1]), 
									Integer.parseInt(startDate[2])
							),
							LocalDate.of(
									Integer.parseInt(endDate[0]),
									Integer.parseInt(endDate[1]),
									Integer.parseInt(endDate[2])
							)
						).toString()
						+ " SEK"
					);
				}
				else {
					//System.out.println("OK");
					String[] startDate = tfGetMarkHLStart.getText().split("-");
					String[] endDate = tfGetMarkHLEnd.getText().split("-");
					getMarkHLText.setText(
						calcModel.getLowMark(
							comBoxGetMarkHLCur.getValue().toString(), 
							LocalDate.of(
									Integer.parseInt(startDate[0]), 
									Integer.parseInt(startDate[1]), 
									Integer.parseInt(startDate[2])
							),
							LocalDate.of(
									Integer.parseInt(endDate[0]),
									Integer.parseInt(endDate[1]),
									Integer.parseInt(endDate[2])
							)
						).toString()
						+ " SEK"
					);
				}
			}	
		});
		
		// Create a scene.
		VBox layoutHolder = new VBox(10);
		
		// Inside layoutHolder.
		// GetYearAverage.
		VBox getYearAverageBoxBase = new VBox(10); 
		HBox getYearAverageBox = new HBox(20);
		
		getYearAverageBoxBase.getChildren().addAll(getYearAverageHead, getYearAverageBox);
		getYearAverageBox.getChildren().addAll(comBoxGetYearAverageCur, comBoxGetYearAverageY, getYearAverageText);
		
		// GetMonthAverage.
		VBox getMonthAverageBoxBase = new VBox(10);
		HBox getMonthAverageBox = new HBox(20);
		
		getMonthAverageBoxBase.getChildren().addAll(getMonthAverageHead, getMonthAverageBox);
		getMonthAverageBox.getChildren().addAll(comBoxGetMonthAverageCur, comBoxGetMonthAverageY, comBoxGetMonthAverageM, getMonthAverageText);
		
		// GetAveragePeriod.
		VBox getAveragePeriodBoxBase = new VBox(10);
		HBox getAveragePeriodBox = new HBox(20);
		
		getAveragePeriodBoxBase.getChildren().addAll(getAveragePeriodHead, getAveragePeriodBox, buttonGetAveragePeriodCommit);
		getAveragePeriodBox.getChildren().addAll(comBoxGetAveragePeriodCur, tfGetAveragePeriodStart, tfGetAveragePeriodEnd, getAveragePeriodText);
		
		// getYearHigh and getYearLow.
		VBox getYearHLBoxBase = new VBox(10);
		HBox getYearHLBox = new HBox(20);
		
		getYearHLBoxBase.getChildren().addAll(getYearHLHead, getYearHLBox);
		getYearHLBox.getChildren().addAll(comBoxYearHL, comBoxYearHLCur, comBoxYearY, getYearHLText);
		
		// getMonthHigh and getMonthLow.
		VBox getMonthHLBoxBase = new VBox(10);
		HBox getMonthHLBox = new HBox(20);
		
		getMonthHLBoxBase.getChildren().addAll(getMonthHLHead, getMonthHLBox);
		getMonthHLBox.getChildren().addAll(comBoxMonthHL, comBoxMonthHLCur, comBoxMonthY, comBoxMonthM, getMonthHLText);
		
		// getHighMark and getLowMark.
		VBox getMarkHLBoxBase = new VBox(10);
		HBox getMarkHLBox = new HBox(20);
		
		getMarkHLBoxBase.getChildren().addAll(getMarkHLHead, getMarkHLBox, buttonGetMarkHLCommit);
		getMarkHLBox.getChildren().addAll(comBoxGetMarkHL, comBoxGetMarkHLCur, tfGetMarkHLStart, tfGetMarkHLEnd, getMarkHLText);
		
		// add objects to scene
		layoutHolder.getChildren().addAll(
				getYearAverageBoxBase,
				getMonthAverageBoxBase,
				getAveragePeriodBoxBase,
				getYearHLBoxBase,
				getMonthHLBoxBase,
				getMarkHLBoxBase
		);
		
		// Set the scene on the stage.
		Scene myScene = new Scene(layoutHolder, 620, 450);
		myStage.setScene(myScene);

		// Show the stage and its scene.
		myStage.show();
	}
	
	void alert(String text) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Information Dialog");
		alert.setHeaderText(null);
		alert.setContentText(text);

		alert.showAndWait();
	}
	
	void checkCombo(ComboBox checkThisbox, ComboBox editThisbox) {
		if (checkThisbox.getValue().toString().equals("2013")) {
			editThisbox.setValue("November");
			editThisbox.setItems(monthOptions2013);
		}
		else if(checkThisbox.getValue().toString().equals("2014")) {
			editThisbox.setValue("November");
			editThisbox.setItems(monthOptions2014);
		}
		else if(checkThisbox.getValue().toString().equals("2015")) {
			editThisbox.setValue("November");
			editThisbox.setItems(monthOptions2015);
		}
	}
	
	public void stop() {
		
	}
}
