package se.plushogskolan.ju15.beans;

import java.math.BigDecimal;

public class CurrencyCalcBean {
	private BigDecimal currency;
	private String currencyName;
	private Integer day;
	private Integer month;
	private Integer year;
   
	public CurrencyCalcBean() {
	   
	}
   
	public CurrencyCalcBean(BigDecimal currency, String currencyName, Integer day, Integer month, Integer year) {
		this.setCurrency(currency);
		this.setCurrencyName(currencyName);
		this.setDay(day);
		this.setMonth(month);
		this.setYear(year);
	}

	public BigDecimal getCurrency() {
		return currency;
	}

	public void setCurrency(BigDecimal currency) {
		this.currency = currency;
	}

	public String getCurrencyName() {
		return currencyName;
	}

	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}

	public Integer getDay() {
		return day;
	}

	public void setDay(Integer day) {
		this.day = day;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}
}
